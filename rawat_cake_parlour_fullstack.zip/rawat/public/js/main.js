/* ═══════════════════════════════════════════════
   Rawat Cake Parlour — Frontend JavaScript
   API-connected, dynamic food rendering
   ═══════════════════════════════════════════════ */

const API = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1'
  ? 'http://localhost:3000/api'
  : '/api';

// ── State ────────────────────────────────────────
let allFoods = [];
let cart = JSON.parse(localStorage.getItem('rcp-cart') || '[]');
let currentQty = 1;
let currentFood = null;

// ── DOM Refs ─────────────────────────────────────
const foodGrid      = document.getElementById('foodGrid');
const cartBadge     = document.getElementById('cartBadge');
const cartTrigger   = document.getElementById('cartTrigger');
const cartOverlay   = document.getElementById('cartOverlay');
const cartDrawer    = document.getElementById('cartDrawer');
const cartItems     = document.getElementById('cartItems');
const cartFooter    = document.getElementById('cartFooter');
const cartClose     = document.getElementById('cartClose');
const navbar        = document.getElementById('navbar');
const hamburger     = document.getElementById('hamburger');
const navLinks      = document.getElementById('navLinks');
const searchToggle  = document.getElementById('searchToggle');
const searchPanel   = document.getElementById('searchPanel');
const searchInput   = document.getElementById('searchInput');
const searchResults = document.getElementById('searchResults');
const modalOverlay  = document.getElementById('modalOverlay');
const modalClose    = document.getElementById('modalClose');
const qtyMinus      = document.getElementById('qtyMinus');
const qtyPlus       = document.getElementById('qtyPlus');
const qtyVal        = document.getElementById('qtyVal');
const orderBtn      = document.getElementById('orderBtn');
const toast         = document.getElementById('toast');

// ── FETCH FOODS ──────────────────────────────────
async function fetchFoods(category = 'all') {
  try {
    const url = category === 'all' ? `${API}/foods` : `${API}/foods?category=${category}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('API error');
    const json = await res.json();
    return json.data;
  } catch {
    // Fallback to local data for demo purposes
    return getFallbackFoods(category);
  }
}

function getFallbackFoods(category) {
  const foods = [
    { id:'c001', name:'Red Velvet Royale', category:'cake', price:549, description:'A stunning three-layer red velvet cake with silky cream cheese frosting, fresh strawberries, and a moist buttery crumb. Perfect for birthdays and anniversaries.', emoji:'🎂', badge:'Bestseller', rating:4.9, reviews:312, tags:['Egg','Custom Available','Serves 6-8'], imageUrl:'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&q=85' },
    { id:'c002', name:'Dark Chocolate Truffle', category:'cake', price:649, description:'Rich Belgian dark chocolate sponge layered with velvety ganache, hand-rolled truffles, and a glossy mirror glaze. An indulgent masterpiece.', emoji:'🎂', badge:'Premium', rating:5.0, reviews:487, tags:['Egg','Premium','Custom Available'], imageUrl:'https://images.unsplash.com/photo-1606890737304-57a1ca8a5b62?w=600&q=85' },
    { id:'c003', name:'Black Forest Classic', category:'cake', price:499, description:'Layers of chocolate sponge, fresh whipped cream, and premium dark cherries. A timeless celebration classic that never goes out of style.', emoji:'🎂', badge:'Classic', rating:4.8, reviews:241, tags:['Egg','Fresh Cream','Classic'], imageUrl:'https://images.unsplash.com/photo-1565958011703-44f9829ba187?w=600&q=85' },
    { id:'c004', name:'Butterscotch Delight', category:'cake', price:449, description:'Moist butterscotch sponge with caramel-infused cream, crunchy praline bits, and a golden caramel drizzle. Irresistibly indulgent.', emoji:'🎂', badge:'Popular', rating:4.8, reviews:198, tags:['Egg','Crunchy','Caramel'], imageUrl:'https://images.unsplash.com/photo-1557925923-33b27f640c36?w=600&q=85' },
    { id:'c005', name:'Strawberry Fantasy', category:'cake', price:529, description:'Layers of vanilla sponge with fresh strawberry compote and whipped mascarpone cream. Light, fresh, and divine.', emoji:'🎂', badge:'New', rating:4.7, reviews:134, tags:['Egg','Fresh Fruit','Light'], imageUrl:'https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?w=600&q=85' },
    { id:'f001', name:'Rawat Spicy Burger', category:'fastfood', price:179, description:'Crispy fried chicken marinated in our 12-spice blend, with iceberg lettuce, jalapeños, and sriracha mayo in a toasted brioche bun.', emoji:'🍔', badge:'🔥 Hot', rating:4.9, reviews:563, tags:['Non-Veg','Spicy','Bestseller'], imageUrl:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=85' },
    { id:'f002', name:'Loaded Cheese Pizza', category:'fastfood', price:299, description:'Hand-tossed thin crust with three-cheese blend, roasted peppers, caramelised onions, and a rich tomato-herb base. Finished with fresh basil.', emoji:'🍕', badge:'Popular', rating:4.8, reviews:389, tags:['Veg','Cheesy','Thin Crust'], imageUrl:'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&q=85' },
    { id:'f003', name:'Schezwan Fire Momos', category:'fastfood', price:99, description:'Steamed dumplings stuffed with spiced vegetables, tossed in our fiery house-made schezwan sauce. Made fresh every hour.', emoji:'🥟', badge:'🔥 Trending', rating:4.9, reviews:621, tags:['Veg','Spicy','Street Style'], imageUrl:'https://images.unsplash.com/photo-1496116218417-1a781b1c416c?w=600&q=85' },
    { id:'f004', name:'Crispy Cheese Fries', category:'fastfood', price:99, description:'Thick-cut golden fries smothered in cheddar cheese sauce, jalapeños, spring onions, and sour cream. The ultimate guilty pleasure.', emoji:'🍟', badge:'Popular', rating:4.7, reviews:534, tags:['Veg','Cheesy','Shareable'], imageUrl:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=600&q=85' },
    { id:'f005', name:'Club Sandwich Stack', category:'fastfood', price:149, description:'Triple-decker toasted sandwich with grilled chicken, fresh lettuce, tomato, cucumber, and signature mustard mayo.', emoji:'🥪', badge:'New', rating:4.6, reviews:178, tags:['Non-Veg','Filling','Fresh'], imageUrl:'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?w=600&q=85' },
  ];
  if (category === 'all') return foods;
  return foods.filter(f => f.category === category);
}

// ── RENDER FOODS ─────────────────────────────────
function getBadgeClass(badge) {
  const b = badge.toLowerCase();
  if (b.includes('veg') && !b.includes('non')) return 'veg';
  if (b.includes('new')) return 'new-badge';
  if (b.includes('premium') || b.includes('classic')) return 'premium';
  return '';
}

function starStr(r) {
  return r >= 5 ? '★★★★★' : r >= 4.8 ? '★★★★★' : r >= 4.6 ? '★★★★½' : '★★★★';
}

function renderFoods(foods) {
  if (!foods.length) {
    foodGrid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:60px;color:var(--muted)">No items found.</div>';
    return;
  }
  foodGrid.innerHTML = foods.map(f => `
    <div class="food-card" data-id="${f.id}" role="button" tabindex="0" aria-label="View ${f.name}">
      <div class="food-card-img">
        ${f.imageUrl
          ? `<img src="${f.imageUrl}" alt="${f.name}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'">`
          : ''
        }
        <div class="emoji-fallback" style="${f.imageUrl ? 'display:none' : ''}">${f.emoji || '🎂'}</div>
        <span class="food-badge ${getBadgeClass(f.badge)}">${f.badge}</span>
      </div>
      <div class="food-card-body">
        <div class="food-rating">
          <span class="stars">${starStr(f.rating)}</span>
          ${f.rating} <span>(${f.reviews})</span>
        </div>
        <div class="food-name">${f.name}</div>
        <div class="food-desc">${f.description.slice(0, 75)}…</div>
        <div class="food-footer">
          <div class="food-price">₹${f.price}</div>
          <button class="food-add" data-id="${f.id}">+ Add</button>
        </div>
      </div>
    </div>
  `).join('');

  // Bind clicks
  foodGrid.querySelectorAll('.food-card').forEach(card => {
    card.addEventListener('click', e => {
      if (!e.target.classList.contains('food-add')) openModal(card.dataset.id);
    });
    card.addEventListener('keydown', e => { if (e.key === 'Enter') openModal(card.dataset.id); });
  });
  foodGrid.querySelectorAll('.food-add').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      const food = allFoods.find(f => f.id === btn.dataset.id);
      if (food) { addToCart(food, 1); btn.textContent = '✓ Added'; btn.classList.add('added'); setTimeout(() => { btn.textContent = '+ Add'; btn.classList.remove('added'); }, 1500); }
    });
  });

  // Stagger reveal
  setTimeout(() => {
    foodGrid.querySelectorAll('.food-card').forEach((card, i) => {
      setTimeout(() => card.classList.add('revealed'), i * 60);
    });
  }, 50);
}

async function loadFoods(category = 'all') {
  foodGrid.innerHTML = '<div class="grid-loader"><div class="loader-spinner"></div><p>Loading fresh items…</p></div>';
  const foods = await fetchFoods(category);
  allFoods = category === 'all' ? foods : [...(allFoods.filter(f => f.category !== category)), ...foods];
  if (category === 'all') allFoods = foods;
  renderFoods(foods);
}

// ── MODAL ────────────────────────────────────────
function openModal(id) {
  const food = allFoods.find(f => f.id === id);
  if (!food) return;
  currentFood = food;
  currentQty = 1;
  qtyVal.textContent = 1;

  document.getElementById('modalImgWrap').innerHTML = food.imageUrl
    ? `<img src="${food.imageUrl}" alt="${food.name}" onerror="this.parentElement.innerHTML='<div class=\\'modal-emoji\\'>${food.emoji}</div>'">`
    : `<div class="modal-emoji">${food.emoji}</div>`;

  document.getElementById('modalMeta').innerHTML = `<span class="modal-cat-badge">${food.category === 'cake' ? '🎂 Cake' : '🍔 Fast Food'}</span>`;
  document.getElementById('modalTitle').textContent = food.name;
  document.getElementById('modalRating').innerHTML = `<span class="stars">${starStr(food.rating)}</span> ${food.rating} (${food.reviews} reviews)`;
  document.getElementById('modalDesc').textContent = food.description;
  document.getElementById('modalPrice').textContent = `₹${food.price}`;
  document.getElementById('modalTags').innerHTML = (food.tags || []).map(t => `<span class="modal-tag">${t}</span>`).join('');
  orderBtn.textContent = 'Add to Cart';
  orderBtn.classList.remove('added');

  modalOverlay.classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeModal() {
  modalOverlay.classList.remove('open');
  document.body.style.overflow = '';
}
modalClose.addEventListener('click', closeModal);
modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });

// Quantity
qtyMinus.addEventListener('click', () => { currentQty = Math.max(1, currentQty - 1); qtyVal.textContent = currentQty; });
qtyPlus.addEventListener('click', () => { currentQty = Math.min(10, currentQty + 1); qtyVal.textContent = currentQty; });
orderBtn.addEventListener('click', () => {
  if (currentFood) {
    addToCart(currentFood, currentQty);
    orderBtn.textContent = '✓ Added!';
    orderBtn.classList.add('added');
    setTimeout(closeModal, 1000);
  }
});

// ── CART ─────────────────────────────────────────
function saveCart() { localStorage.setItem('rcp-cart', JSON.stringify(cart)); }

function addToCart(food, qty = 1) {
  const existing = cart.find(i => i.id === food.id);
  if (existing) { existing.qty += qty; }
  else { cart.push({ id: food.id, name: food.name, price: food.price, emoji: food.emoji, imageUrl: food.imageUrl, qty }); }
  saveCart();
  updateCartUI();
  showToast(`🛒 ${food.name} added to cart — ₹${food.price * qty}`);
}

function updateCartUI() {
  const total = cart.reduce((s, i) => s + i.qty, 0);
  cartBadge.textContent = total;

  if (!cart.length) {
    cartItems.innerHTML = '<div class="cart-empty"><p>🛒</p><span>Your cart is empty</span></div>';
    cartFooter.innerHTML = '';
    return;
  }
  cartItems.innerHTML = cart.map(item => `
    <div class="cart-item" data-id="${item.id}">
      <div class="ci-img">
        ${item.imageUrl ? `<img src="${item.imageUrl}" alt="${item.name}" style="width:52px;height:52px;border-radius:10px;object-fit:cover" onerror="this.parentElement.innerHTML='${item.emoji}'">` : item.emoji}
      </div>
      <div class="ci-info">
        <div class="ci-name">${item.name}</div>
        <div class="ci-price">₹${item.price} × ${item.qty} = ₹${item.price * item.qty}</div>
      </div>
      <div class="ci-qty">
        <button class="ci-qty-btn" data-action="dec" data-id="${item.id}">−</button>
        <span class="ci-qty-val">${item.qty}</span>
        <button class="ci-qty-btn" data-action="inc" data-id="${item.id}">+</button>
      </div>
    </div>
  `).join('');

  cartItems.querySelectorAll('.ci-qty-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.dataset.id;
      const item = cart.find(i => i.id === id);
      if (!item) return;
      if (btn.dataset.action === 'inc') item.qty++;
      else { item.qty--; if (item.qty <= 0) cart.splice(cart.indexOf(item), 1); }
      saveCart(); updateCartUI();
    });
  });

  const grandTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);
  cartFooter.innerHTML = `
    <div class="cart-total">
      <span class="ct-label">Total Amount</span>
      <span class="ct-val">₹${grandTotal}</span>
    </div>
    <button class="checkout-btn" onclick="placeOrder()">Place Order — ₹${grandTotal}</button>
  `;
}

async function placeOrder() {
  if (!cart.length) return;
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  try {
    await fetch(`${API}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items: cart, total, customerName: 'Guest', phone: '', address: '' })
    });
  } catch {}
  cart = []; saveCart(); updateCartUI();
  closeCartDrawer();
  showToast('🎉 Order placed successfully! We\'ll deliver in 30 minutes.');
}

// Cart drawer
function openCartDrawer() { cartOverlay.classList.add('open'); cartDrawer.classList.add('open'); document.body.style.overflow = 'hidden'; }
function closeCartDrawer() { cartOverlay.classList.remove('open'); cartDrawer.classList.remove('open'); document.body.style.overflow = ''; }
cartTrigger.addEventListener('click', openCartDrawer);
cartClose.addEventListener('click', closeCartDrawer);
cartOverlay.addEventListener('click', closeCartDrawer);

// ── SEARCH ───────────────────────────────────────
searchToggle.addEventListener('click', () => {
  searchPanel.classList.toggle('open');
  if (searchPanel.classList.contains('open')) searchInput.focus();
  else { searchInput.value = ''; searchResults.innerHTML = ''; }
});
document.addEventListener('click', e => {
  if (!searchToggle.contains(e.target) && !searchPanel.contains(e.target)) {
    searchPanel.classList.remove('open');
  }
});
searchInput.addEventListener('input', () => {
  const q = searchInput.value.trim().toLowerCase();
  if (!q) { searchResults.innerHTML = ''; return; }
  const matches = allFoods.filter(f => f.name.toLowerCase().includes(q) || f.description.toLowerCase().includes(q) || f.category.toLowerCase().includes(q));
  if (!matches.length) {
    searchResults.innerHTML = '<div class="sr-empty">No results found</div>';
    return;
  }
  searchResults.innerHTML = matches.slice(0, 6).map(f => `
    <div class="sr-item" data-id="${f.id}">
      ${f.imageUrl
        ? `<img src="${f.imageUrl}" alt="${f.name}" class="sr-thumb" onerror="this.outerHTML='<div class=\\'sr-thumb\\' style=\\'display:flex;align-items:center;justify-content:center;font-size:1.5rem;\\'>${f.emoji}</div>'">`
        : `<div class="sr-thumb" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;">${f.emoji}</div>`}
      <div class="sr-info">
        <div class="sr-name">${f.name}</div>
        <div class="sr-price">₹${f.price}</div>
      </div>
    </div>
  `).join('');
  searchResults.querySelectorAll('.sr-item').forEach(item => {
    item.addEventListener('click', () => {
      openModal(item.dataset.id);
      searchPanel.classList.remove('open');
      searchInput.value = '';
      searchResults.innerHTML = '';
    });
  });
});

// ── MENU TABS ────────────────────────────────────
document.querySelectorAll('.tab-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    loadFoods(btn.dataset.cat);
  });
});

// ── NAVBAR ───────────────────────────────────────
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 40);
  // Active nav link
  const secs = ['home', 'menu', 'about', 'contact'];
  let current = 'home';
  secs.forEach(id => {
    const el = document.getElementById(id);
    if (el && window.scrollY >= el.offsetTop - 100) current = id;
  });
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.toggle('active', link.getAttribute('href') === `#${current}`);
  });
  // Reveal elements
  document.querySelectorAll('[data-reveal]:not(.revealed)').forEach(el => {
    if (el.getBoundingClientRect().top < window.innerHeight - 80) el.classList.add('revealed');
  });
});

hamburger.addEventListener('click', () => navLinks.classList.toggle('open'));
document.querySelectorAll('.nav-link').forEach(a => {
  a.addEventListener('click', () => navLinks.classList.remove('open'));
});

// ── TOAST ────────────────────────────────────────
let toastTimeout;
function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => toast.classList.remove('show'), 3000);
}

// ── INIT ─────────────────────────────────────────
(async function init() {
  updateCartUI();
  await loadFoods('all');
  // Initial reveal for elements in view
  setTimeout(() => {
    document.querySelectorAll('[data-reveal]').forEach(el => {
      if (el.getBoundingClientRect().top < window.innerHeight) el.classList.add('revealed');
    });
  }, 100);
})();
